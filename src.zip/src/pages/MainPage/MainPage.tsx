import { Navbar } from "../../components/Navbar/Navbar";
import { ScoreTable } from "../../components/ScoreTable/ScoreTable";

export const MainPage = () => {
  return (
    <div>
      <Navbar />
      <ScoreTable />
    </div>
  );
};
