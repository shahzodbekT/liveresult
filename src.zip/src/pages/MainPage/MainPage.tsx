import { Navbar } from "../../components/Navbar/Navbar";

export const MainPage = () => {
  return (
    <div>
      <Navbar />
    </div>
  );
};
