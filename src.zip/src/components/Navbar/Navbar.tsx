export const Navbar = () => {
  return (
    <div className="navbar bg-base-100">
      <a href="https://youtu.be/dQw4w9WgXcQ?si=DQ01dN5UokeMtIhV" className="btn btn-ghost text-xl">LiveResult</a>
    </div>
  );
};
