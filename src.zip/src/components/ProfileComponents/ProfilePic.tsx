export const ProfilePic = () => {
  return(
    <div className="avatar">
    <div className="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
      <img src="https://cdn.images.express.co.uk/img/dynamic/79/590x/secondary/4782404.jpg?r=1685574665586" alt="rick-astley" />
    </div>
  </div>
  )
};
